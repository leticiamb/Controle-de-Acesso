#ifndef LMB_CONTROLE_H
#define LMB_CONTROLE_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "dao.h"
#include "cartao.h"

void iniciar();

#endif // LMB_CONTROLE_H
